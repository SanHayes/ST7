import{a6 as t}from"./index-B5cGjNwt.js";function r(){return t({method:"GET",url:"/quotation_new"})}function a(o){return t({method:"POST",url:"/klineMarketHome",data:o})}export{a as g,r as q};
